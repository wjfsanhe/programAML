#include "osd.h"

int  main (char argc ,char **argv)
{
#define  OSD1_COLOR_MODE 32 
    osd_obj_t  *osd ;
    
    printf("create one osd object on fb0\n");
    osd=create_osd_obj(OSD1_COLOR_MODE,0);
    if(argv[1]!=NULL)
    {
          osd->pic_name=argv[1];
    }else{
          osd->pic_name=NULL;
    }
    
    if(NULL==osd) 
    {
	printf("can't create osd object for  osd0\r\n");
	return -1;
    }
    printf("start show one picture on osd0\n");
    osd->show(osd);
    
    return 0;
}