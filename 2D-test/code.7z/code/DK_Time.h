#ifndef DK_TIME_H
#define DK_TIME_H

double mysecond();

#endif
