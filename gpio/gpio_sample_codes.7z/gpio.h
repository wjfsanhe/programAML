#ifndef  _GPIO_H_
#define _GPIO_H_

#define   GPIO_DEV    "/dev/uio1"
#define	GPIO_ADDR      	"/sys/class/gpio/gpio_dev/uio1/maps/map0/addr"
#define	GPIO_SIZE		"/sys/class/gpio/gpio_dev/uio1/maps/map0/size"
#define	GPIO_OFFSET	"/sys/class/gpio/gpio_dev/uio1/maps/map0/offset"


typedef enum gpio_bank
{
	PREG_EGPIO=0,
	PREG_FGPIO,
	PREG_GGPIO,
	PREG_HGPIO
}gpio_bank_t;
typedef enum gpio_mode
{
	GPIO_OUTPUT_MODE,
	GPIO_INPUT_MODE,
}gpio_mode_t;

struct gpio_addr
{
	unsigned long mode_addr;
	unsigned long out_addr;
	unsigned long in_addr;
};

// Pre-defined GPIO addresses
// ----------------------------
#define PREG_EGPIO_EN_N                          	0
#define PREG_EGPIO_O                                	1
#define PREG_EGPIO_I                               	2
// ----------------------------
#define PREG_FGPIO_EN_N                            	3
#define PREG_FGPIO_O                            		4
#define PREG_FGPIO_I                        	       5
// ----------------------------
#define PREG_GGPIO_EN_N                            	6
#define PREG_GGPIO_O                               	7
#define PREG_GGPIO_I                               	8
// ----------------------------
#define PREG_HGPIO_EN_N                            	9
#define PREG_HGPIO_O                               	10
#define PREG_HGPIO_I                               	11

#define GPIOA_bank					(PREG_EGPIO)
#define GPIOA_bit(bit)					(bit>22?bit-23:bit+4)


										
#define GPIOB_bank					(PREG_EGPIO)
#define GPIOB_bit(bit)					(bit+19)		

#define GPIOC_bank					(PREG_FGPIO)
#define GPIOC_bit(bit)					(bit)		

#define GPIOD_bank					(PREG_GGPIO)
#define GPIOD_bit(bit)					(bit-2)		

#define GPIOE_bank					(PREG_HGPIO)
#define GPIOE_bit(bit)					(bit)		

	

static struct gpio_addr gpio_addrs[]=
{
	[PREG_EGPIO]={PREG_EGPIO_EN_N,PREG_EGPIO_O,PREG_EGPIO_I},
	[PREG_FGPIO]={PREG_FGPIO_EN_N,PREG_FGPIO_O,PREG_FGPIO_I},
	[PREG_GGPIO]={PREG_GGPIO_EN_N,PREG_GGPIO_O,PREG_GGPIO_I},
	[PREG_HGPIO]={PREG_HGPIO_EN_N,PREG_HGPIO_O,PREG_HGPIO_I},
};
typedef  struct {
	volatile unsigned int *base_reg;
	int offset;
	int size ;
}gpio_t ;


static  gpio_t  gpio;

static inline int set_gpio_mode(gpio_bank_t bank,int bit,gpio_mode_t mode)
{
	volatile unsigned int *mod_reg=&gpio.base_reg[gpio_addrs[bank].mode_addr];
	*mod_reg=(*mod_reg &~(1<<bit))|((mode&1) << bit) ;
	return 0;
}
static inline gpio_mode_t get_gpio_mode(gpio_bank_t bank,int bit)
{
	volatile unsigned int *mod_reg=&gpio.base_reg[gpio_addrs[bank].mode_addr];
	return (*mod_reg &(1<<bit)>0)?(GPIO_INPUT_MODE):(GPIO_OUTPUT_MODE);
}


static inline  int set_gpio_val(gpio_bank_t bank,int bit,unsigned long val)
{
	volatile unsigned int *out_reg=&gpio.base_reg[gpio_addrs[bank].out_addr];
	*out_reg=(*out_reg &~(1<<bit))|((val&1) << bit) ;

	return 0;
}

static inline unsigned long  get_gpio_val(gpio_bank_t bank,int bit)
{
	volatile unsigned int *in_reg=&gpio.base_reg[gpio_addrs[bank].in_addr];
	return (*in_reg &(1<<bit)>0)?1:0;
}


#endif
